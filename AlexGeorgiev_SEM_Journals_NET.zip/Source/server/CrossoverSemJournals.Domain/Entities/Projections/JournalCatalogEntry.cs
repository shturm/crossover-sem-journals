﻿using System;
namespace CrossoverSemJournals.Domain.Entities
{
	public class JournalCatalogEntry
	{
		public int Id { get; set;}
		public string Name { get; set; }
		public decimal Price { get; set; }
	}
}

