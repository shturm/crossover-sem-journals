echo "" | sudo tee /var/log/mysql/mysql.log
