"use strict";
var router_1 = require("@angular/router");
var auth_guard_1 = require("./auth.guard");
var newProductPage_component_1 = require("./pages/newProduct/newProductPage.component");
var browsePage_component_1 = require("./pages/browse/browsePage.component");
var usersPage_component_1 = require("./pages/users/usersPage.component");
var profilePage_component_1 = require("./pages/profile/profilePage.component");
var registerPage_component_1 = require("./pages/register/registerPage.component");
var loginPage_component_1 = require("./pages/login/loginPage.component");
var productDetailsPage_component_1 = require("./pages/productDetails/productDetailsPage.component");
var paperDetailsPage_component_1 = require("./pages/paperDetails/paperDetailsPage.component");
var appRoutes = [
    { path: 'browse', component: browsePage_component_1.BrowsePageComponent, canActivate: [auth_guard_1.AuthGuard] },
    { path: 'browse/search/:term', component: browsePage_component_1.BrowsePageComponent, canActivate: [auth_guard_1.AuthGuard] },
    { path: 'read/:paperId/:pageNumber', component: paperDetailsPage_component_1.PaperDetailsPageComponent, canActivate: [auth_guard_1.AuthGuard] },
    { path: 'users', component: usersPage_component_1.UsersPageComponent, canActivate: [auth_guard_1.AuthGuard, auth_guard_1.AdminGuard] },
    { path: 'new', component: newProductPage_component_1.NewProductPageComponent, canActivate: [auth_guard_1.AuthGuard, auth_guard_1.AdminGuard] },
    { path: 'profile', component: profilePage_component_1.ProfilePageComponent, canActivate: [auth_guard_1.AuthGuard] },
    { path: '', component: browsePage_component_1.BrowsePageComponent, canActivate: [auth_guard_1.AuthGuard] },
    { path: 'browse/:id', component: productDetailsPage_component_1.ProductDetailsPageComponent, canActivate: [auth_guard_1.AuthGuard] },
    { path: 'register', component: registerPage_component_1.RegisterPageComponent },
    { path: 'login', component: loginPage_component_1.LoginPageComponent }
];
exports.routing = router_1.RouterModule.forRoot(appRoutes);
//# sourceMappingURL=app.routes.js.map