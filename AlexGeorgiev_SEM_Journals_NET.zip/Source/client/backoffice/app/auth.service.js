"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var http_1 = require("@angular/http");
var Observable_1 = require("rxjs/Observable");
var router_1 = require("@angular/router");
var AuthService = (function () {
    function AuthService(router, http) {
        this.router = router;
        this.http = http;
    }
    AuthService.prototype.isLoggedIn = function () {
        var result = !!localStorage.getItem('token');
        return result;
    };
    AuthService.prototype.authorizeHeaders = function (headers) {
        headers.append('Authorization', "Bearer " + localStorage.getItem('token'));
    };
    AuthService.prototype.getAuthorizationHeaderValue = function () {
        return "Bearer " + localStorage.getItem('token');
    };
    AuthService.prototype.login = function (email, password) {
        var _this = this;
        var headers = new http_1.Headers();
        headers.append('Content-Type', 'application/x-www-form-urlencoded');
        var requestOptionsArgs = { headers: headers };
        var encodedData = this.objectToQueryString({
            username: email,
            password: password,
            grant_type: 'password'
        });
        var result = new Observable_1.Observable(function (sub) {
            _this.http.post('http://localhost:8080/token', encodedData, requestOptionsArgs).subscribe(function (r) {
                var token = r.json().access_token;
                localStorage.setItem('token', token);
                localStorage.setItem('user.email', email);
                // who am i
                var whoamiHeaders = new http_1.Headers();
                whoamiHeaders.append('Authorization', "Bearer " + token);
                _this.http.get('http://localhost:8080/api/accounts/whoami', { headers: whoamiHeaders }).subscribe(function (res) {
                    if (res.json().isAdmin) {
                        localStorage.setItem('user.admin', "admin");
                    }
                    sub.next();
                });
            }, function (e) {
                sub.error(e.json().error_description);
            });
        });
        return result;
    };
    AuthService.prototype.userEmail = function () {
        return localStorage.getItem('user.email');
    };
    AuthService.prototype.logout = function () {
        localStorage.removeItem('token');
        localStorage.removeItem('user.email');
        localStorage.removeItem('user.admin');
        this.router.navigate(['login']);
    };
    AuthService.prototype.register = function (email, password) {
        var apiObs = this.http.post('http://localhost:8080/api/accounts/register', {
            email: email,
            password: password
        });
        var result = new Observable_1.Observable(function (subscriber) {
            var errorMessages = '';
            apiObs.subscribe(function () {
                subscriber.next();
            }, function (errorResponse) {
                if (errorResponse.type !== 2) {
                    subscriber.error(errorResponse.text());
                }
                var errorGroups = errorResponse.json().modelState;
                for (var prop in errorGroups) {
                    if (!errorGroups[prop].length || errorGroups[prop].length === 0)
                        continue;
                    errorGroups[prop].forEach(function (err) {
                        errorMessages += err;
                    });
                }
                subscriber.error(errorMessages);
            });
        });
        return result;
    };
    AuthService.prototype.updateProfile = function (profile) {
        var headers = new http_1.Headers();
        this.authorizeHeaders(headers);
        var opts = { headers: headers };
        // headers.append('Content-Type', 'application/x-www-form-urlencoded');
        // let data = this.objectToQueryString({email: profile.email});
        var data = { email: profile.email };
        this.http.post('http://localhost:8080/api/accounts/changeEmail', data, opts).subscribe(function (r) {
            localStorage.setItem('user.email', profile.email);
        });
    };
    AuthService.prototype.isAdmin = function () {
        return !!localStorage.getItem('user.admin');
    };
    AuthService.prototype.objectToQueryString = function (obj) {
        var parts = [];
        for (var i in obj) {
            if (obj.hasOwnProperty(i)) {
                parts.push(encodeURIComponent(i) + '=' + encodeURIComponent(obj[i]));
            }
        }
        return parts.join('&');
    };
    return AuthService;
}());
AuthService = __decorate([
    core_1.Injectable(),
    __metadata("design:paramtypes", [router_1.Router,
        http_1.Http])
], AuthService);
exports.AuthService = AuthService;
//# sourceMappingURL=auth.service.js.map