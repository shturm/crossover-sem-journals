"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var product_model_1 = require("../../product.model");
var paper_model_1 = require("../../paper.model");
var ProductComponent = (function () {
    function ProductComponent() {
        this.editable = true;
        this.onSubmit = new core_1.EventEmitter();
        this.onDeleteJournal = new core_1.EventEmitter();
        this.onSubmitNewPaper = new core_1.EventEmitter();
        this.onDeletePaper = new core_1.EventEmitter();
        this.onReadPaper = new core_1.EventEmitter();
        this.newPaper = new paper_model_1.Paper(0, '', 0);
    }
    ProductComponent.prototype.onFileChange = function (event) {
        this.newPaper.file = event.srcElement.files[0];
    };
    ProductComponent.prototype.submitProduct = function () {
        this.onSubmit.emit(this.product);
        this.product = new product_model_1.Product('', 0);
    };
    ProductComponent.prototype.deletePaper = function (paper) {
        if (confirm('Are you sure you want to delete the paper ?')) {
            this.onDeletePaper.emit(paper);
        }
    };
    ProductComponent.prototype.readPaper = function (paper) {
        this.onReadPaper.emit(paper);
    };
    ProductComponent.prototype.deleteJournal = function (journal) {
        if (confirm('Are you sure you want to delete the journal ?')) {
            this.onDeleteJournal.emit(journal);
        }
    };
    ProductComponent.prototype.submitNewPaper = function (formData) {
        this.onSubmitNewPaper.emit(this.newPaper);
    };
    ProductComponent.prototype.ngOnInit = function () {
    };
    return ProductComponent;
}());
__decorate([
    core_1.Input(),
    __metadata("design:type", product_model_1.Product)
], ProductComponent.prototype, "product", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", Array)
], ProductComponent.prototype, "papers", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", Boolean)
], ProductComponent.prototype, "editable", void 0);
__decorate([
    core_1.Output(),
    __metadata("design:type", Object)
], ProductComponent.prototype, "onSubmit", void 0);
__decorate([
    core_1.Output(),
    __metadata("design:type", Object)
], ProductComponent.prototype, "onDeleteJournal", void 0);
__decorate([
    core_1.Output(),
    __metadata("design:type", Object)
], ProductComponent.prototype, "onSubmitNewPaper", void 0);
__decorate([
    core_1.Output(),
    __metadata("design:type", Object)
], ProductComponent.prototype, "onDeletePaper", void 0);
__decorate([
    core_1.Output(),
    __metadata("design:type", Object)
], ProductComponent.prototype, "onReadPaper", void 0);
ProductComponent = __decorate([
    core_1.Component({
        selector: 'app-product',
        templateUrl: 'app/components/product/product.component.html',
    }),
    __metadata("design:paramtypes", [])
], ProductComponent);
exports.ProductComponent = ProductComponent;
//# sourceMappingURL=product.component.js.map