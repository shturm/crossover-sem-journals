/**
 * Product
 */
export class Page {
    
    // file: File,
    
    constructor(public id: number,
                public pageNumber: number,
                public b64image: string) {}
}