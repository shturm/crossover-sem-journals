"use strict";
/**
 * Product
 */
var Paper = (function () {
    function Paper(id, name, pageCount) {
        this.id = id;
        this.name = name;
        this.pageCount = pageCount;
    }
    return Paper;
}());
exports.Paper = Paper;
//# sourceMappingURL=paper.model.js.map