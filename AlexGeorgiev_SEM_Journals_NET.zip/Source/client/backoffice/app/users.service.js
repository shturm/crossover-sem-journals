"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var http_1 = require("@angular/http");
var Observable_1 = require("rxjs/Observable");
var auth_service_1 = require("./auth.service");
var UsersService = (function () {
    function UsersService(http, auth) {
        this.http = http;
        this.auth = auth;
    }
    UsersService.prototype.getUsers = function () {
        var _this = this;
        var result = new Observable_1.Observable(function (sub) {
            var headers = new http_1.Headers();
            _this.auth.authorizeHeaders(headers);
            var opts = { headers: headers };
            _this.http.get('http://localhost:8080/api/accounts/getall', opts).subscribe(function (r) {
                var users = r.json().map(function (userDto) {
                    return {
                        id: userDto.id,
                        email: userDto.email,
                        isAdmin: userDto.isAdmin
                    };
                });
                sub.next(users);
            });
        });
        return result;
    };
    UsersService.prototype.setUserAdmin = function (email, flag) {
        var _this = this;
        var result = new Observable_1.Observable(function (sub) {
            var headers = new http_1.Headers();
            _this.auth.authorizeHeaders(headers);
            // headers.append('Content-Type', 'application/x-www-form-urlencoded');
            var opts = { headers: headers };
            var data = { email: email, flag: flag };
            _this.http.post('http://localhost:8080/api/accounts/setAdmin', data, opts).subscribe(function (r) {
                sub.next();
            }, function () {
                sub.error();
            });
        });
        return result;
    };
    UsersService.prototype.objectToQueryString = function (obj) {
        var parts = [];
        for (var i in obj) {
            if (obj.hasOwnProperty(i)) {
                parts.push(encodeURIComponent(i) + '=' + encodeURIComponent(obj[i]));
            }
        }
        return parts.join('&');
    };
    return UsersService;
}());
UsersService.users = [
    { email: 'gosho@pochivka.com', admin: true },
    { email: 'qvkata@dlg.com', admin: false },
    { email: 'toncho@gulub.com', admin: false },
    { email: 'mirko@cropcop.com', admin: false },
];
UsersService = __decorate([
    core_1.Injectable(),
    __metadata("design:paramtypes", [http_1.Http,
        auth_service_1.AuthService])
], UsersService);
exports.UsersService = UsersService;
//# sourceMappingURL=users.service.js.map