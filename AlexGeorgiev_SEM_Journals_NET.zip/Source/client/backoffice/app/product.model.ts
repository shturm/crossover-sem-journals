/**
 * Product
 */
export class Product {
    id: string;
    
    constructor(public name: string,
                public price: number
                ) {}
}