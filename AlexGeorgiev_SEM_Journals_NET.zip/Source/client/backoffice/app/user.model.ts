export class User {
    constructor(private id: string,
                private email: string,
                private isAdmin: boolean) {}
}