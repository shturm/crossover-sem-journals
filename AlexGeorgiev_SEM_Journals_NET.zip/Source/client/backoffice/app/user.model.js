"use strict";
var User = (function () {
    function User(id, email, isAdmin) {
        this.id = id;
        this.email = email;
        this.isAdmin = isAdmin;
    }
    return User;
}());
exports.User = User;
//# sourceMappingURL=user.model.js.map