"use strict";
/**
 * Product
 */
var Page = (function () {
    // file: File,
    function Page(id, pageNumber, b64image) {
        this.id = id;
        this.pageNumber = pageNumber;
        this.b64image = b64image;
    }
    return Page;
}());
exports.Page = Page;
//# sourceMappingURL=page.model.js.map