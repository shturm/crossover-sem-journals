"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var auth_service_1 = require("../../auth.service");
var RegisterPageComponent = (function () {
    function RegisterPageComponent(auth, router) {
        this.auth = auth;
        this.router = router;
    }
    RegisterPageComponent.prototype.register = function (credentials) {
        var _this = this;
        if (credentials.password !== credentials.repeatPassword) {
            this.errorMessage = "Passwords don't match";
            return;
        }
        this.auth.register(credentials.email, credentials.password).subscribe(function () {
            _this.errorMessage = "";
            _this.auth.login(credentials.email, credentials.password).subscribe(function () { _this.router.navigate(['browse']); }, function () { _this.router.navigate(['login']); });
        }, function (e) {
            _this.errorMessage = e;
        });
    };
    return RegisterPageComponent;
}());
RegisterPageComponent = __decorate([
    core_1.Component({
        selector: 'app-registerPage',
        templateUrl: 'app/pages/register/registerPage.component.html',
        directives: []
    }),
    __metadata("design:paramtypes", [auth_service_1.AuthService,
        router_1.Router])
], RegisterPageComponent);
exports.RegisterPageComponent = RegisterPageComponent;
//# sourceMappingURL=registerPage.component.js.map