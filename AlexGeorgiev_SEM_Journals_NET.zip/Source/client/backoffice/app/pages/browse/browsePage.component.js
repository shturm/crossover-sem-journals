"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var products_service_1 = require("../../products.service");
var router_1 = require("@angular/router");
var BrowsePageComponent = (function () {
    function BrowsePageComponent(productsService, router, route) {
        this.productsService = productsService;
        this.router = router;
        this.route = route;
        this.products = [];
    }
    BrowsePageComponent.prototype.gotoProduct = function (id) {
        this.router.navigate(['browse', id]);
    };
    BrowsePageComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.route.params.forEach(function (params) {
            _this.searchTerm = params['term'];
        });
        this.productsService.getProducts(this.searchTerm).subscribe(function (products) {
            _this.products = products;
        });
        products_service_1.ProductsService.searchEvent.subscribe(function (term) {
            _this.productsService.getProducts(term).subscribe(function (products) {
                _this.products = products;
            });
        });
    };
    BrowsePageComponent.prototype.deleteProduct = function (p) {
        var _this = this;
        this.productsService.deleteJournal(p).then(function () {
            _this.products.forEach(function (prod, index) {
                if (p.id === prod.id) {
                    _this.products.splice(index, 1);
                }
            });
        });
    };
    return BrowsePageComponent;
}());
BrowsePageComponent = __decorate([
    core_1.Component({
        moduleId: module.id,
        providers: [products_service_1.ProductsService],
        selector: 'app-browsePage',
        templateUrl: 'browsePage.component.html',
        styles: ['']
    }),
    __metadata("design:paramtypes", [products_service_1.ProductsService,
        router_1.Router,
        router_1.ActivatedRoute])
], BrowsePageComponent);
exports.BrowsePageComponent = BrowsePageComponent;
//# sourceMappingURL=browsePage.component.js.map