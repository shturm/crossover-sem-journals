"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var auth_service_1 = require("../../auth.service");
var platform_browser_1 = require("@angular/platform-browser");
var product_component_1 = require("../../components/product/product.component");
var page_model_1 = require("../../page.model");
var products_service_1 = require("../../products.service");
var PaperDetailsPageComponent = (function () {
    function PaperDetailsPageComponent(route, router, auth, productsService, sanitizer) {
        this.route = route;
        this.router = router;
        this.auth = auth;
        this.productsService = productsService;
        this.sanitizer = sanitizer;
    }
    PaperDetailsPageComponent.prototype.ngOnInit = function () {
        var _this = this;
        // this.product = this.productsService.findProduct(id);
        this.route.params.forEach(function (params) {
            var pageNumber = params['pageNumber'];
            var paperId = params['paperId'];
            _this.updateData(paperId, pageNumber);
        });
    };
    PaperDetailsPageComponent.prototype.updateData = function (paperId, pageNumber) {
        var _this = this;
        this.productsService.getPaper(paperId).then(function (paper) {
            _this.paper = paper;
        });
        this.productsService.getPaperPage(paperId, pageNumber).then(function (pageImageb64) {
            _this.paperPage = new page_model_1.Page(0, pageNumber, pageImageb64);
            _this.b64 = pageImageb64;
            _this.b64sanitized = _this.sanitizer.bypassSecurityTrustUrl("data:image/jpeg;base64," + _this.b64);
        });
    };
    PaperDetailsPageComponent.prototype.nextPage = function () {
        this.updateData(this.paper.id, this.paperPage.pageNumber + 1);
    };
    PaperDetailsPageComponent.prototype.previousPage = function () {
        this.updateData(this.paper.id, this.paperPage.pageNumber - 1);
    };
    return PaperDetailsPageComponent;
}());
PaperDetailsPageComponent = __decorate([
    core_1.Component({
        moduleId: module.id,
        templateUrl: 'paperDetailsPage.component.html',
        directives: [product_component_1.ProductComponent],
        providers: [products_service_1.ProductsService]
    }),
    __metadata("design:paramtypes", [router_1.ActivatedRoute,
        router_1.Router,
        auth_service_1.AuthService,
        products_service_1.ProductsService,
        platform_browser_1.DomSanitizationService])
], PaperDetailsPageComponent);
exports.PaperDetailsPageComponent = PaperDetailsPageComponent;
//# sourceMappingURL=paperDetailsPage.component.js.map