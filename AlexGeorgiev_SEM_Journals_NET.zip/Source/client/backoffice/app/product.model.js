"use strict";
/**
 * Product
 */
var Product = (function () {
    function Product(name, price) {
        this.name = name;
        this.price = price;
    }
    return Product;
}());
exports.Product = Product;
//# sourceMappingURL=product.model.js.map