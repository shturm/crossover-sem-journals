"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var auth_service_1 = require("./auth.service");
var http_1 = require("@angular/http");
var Observable_1 = require("rxjs/Observable");
require("rxjs/add/operator/toPromise");
var ProductsService = (function () {
    function ProductsService(router, http, auth) {
        this.router = router;
        this.http = http;
        this.auth = auth;
    }
    ProductsService.prototype.findProduct = function (journalId) {
        var _this = this;
        var headers = new http_1.Headers();
        this.auth.authorizeHeaders(headers);
        var opts = { headers: headers };
        var result = new Observable_1.Observable(function (sub) {
            _this.http.get('http://localhost:8080/api/journals/subscription?journalId=' + encodeURIComponent(journalId), opts)
                .subscribe(function (journalResponse) {
                _this.http.get('http://localhost:8080/api/papers?journalId=' + encodeURIComponent(journalId), opts)
                    .subscribe(function (papersResponse) {
                    sub.next({
                        papers: papersResponse.json(),
                        journal: journalResponse.json()
                    });
                });
            });
        });
        return result;
    };
    ProductsService.prototype.getProducts = function (term) {
        var _this = this;
        var result = new Observable_1.Observable(function (sub) {
            var headers = new http_1.Headers();
            _this.auth.authorizeHeaders(headers);
            var opts = { headers: headers };
            var url = 'http://localhost:8080/api/journals/subscriptions';
            if (term) {
                url += '?term=' + encodeURIComponent(term);
            }
            _this.http.get(url, opts).subscribe(function (r) {
                sub.next(r.json());
            }, function (e) {
                console.log(e);
            });
        });
        return result;
    };
    ProductsService.prototype.createProduct = function (p) {
        var headers = new http_1.Headers();
        this.auth.authorizeHeaders(headers);
        headers.append('Content-Type', 'application/json');
        var opts = { headers: headers };
        // let data = this.objectToQueryString(p);
        var data = p;
        return this.http.post('http://localhost:8080/api/journals', data, opts).toPromise();
    };
    ProductsService.prototype.updateProduct = function (p) {
        var _this = this;
        var result = new Observable_1.Observable(function (sub) {
            var headers = new http_1.Headers();
            _this.auth.authorizeHeaders(headers);
            var opts = { headers: headers };
            _this.http.put('http://localhost:8080/api/journals', p, opts).subscribe(function (r) {
                sub.next(r);
            }, function (e) {
                sub.error(e);
                console.log(e);
            });
        });
        return result;
    };
    ProductsService.prototype.subscribeToJournal = function (journal) {
        var headers = new http_1.Headers();
        this.auth.authorizeHeaders(headers);
        var opts = { headers: headers };
        return this.http.post('http://localhost:8080/api/journals/subscribe?journalId=' + journal.id, {}, opts).toPromise();
    };
    ProductsService.prototype.unsubscribeFromJournal = function (journal) {
        var headers = new http_1.Headers();
        this.auth.authorizeHeaders(headers);
        var opts = { headers: headers };
        return this.http.post('http://localhost:8080/api/journals/unsubscribe?journalId=' + journal.id, {}, opts).toPromise();
    };
    ProductsService.prototype.deleteJournal = function (p) {
        var headers = new http_1.Headers();
        this.auth.authorizeHeaders(headers);
        var opts = { headers: headers };
        return this.http.delete('http://localhost:8080/api/journals?journalId=' + p.id, opts).toPromise();
    };
    ProductsService.prototype.addPaperToJournal = function (paper, journalId) {
        var _this = this;
        var pr = new Promise(function (resolve, reject) {
            console.log(paper);
            var xhr = new XMLHttpRequest();
            var formData = new FormData();
            formData.append('paperFile', paper.file);
            formData.append('paperName', paper.name);
            formData.append('journalId', journalId);
            xhr.setRequestHeader("Authorization", _this.auth.getAuthorizationHeaderValue());
            xhr.onreadystatechange = function (e) {
                if (4 == this.readyState) {
                    resolve();
                }
            };
            xhr.open('post', 'http://localhost:8080/api/papers');
            xhr.send(formData);
        });
        return pr;
    };
    ProductsService.prototype.deletePaper = function (paperId) {
        var headers = new http_1.Headers();
        this.auth.authorizeHeaders(headers);
        var opts = { headers: headers };
        return this.http.delete('http://localhost:8080/api/papers?paperId=' + paperId, opts).toPromise();
    };
    ProductsService.prototype.getPaper = function (paperId) {
        var headers = new http_1.Headers();
        this.auth.authorizeHeaders(headers);
        var opts = { headers: headers };
        var getPaperPromise = this.http.get('http://localhost:8080/api/papers?paperId=' + paperId, opts).toPromise();
        var result = new Promise(function (resolve, reject) {
            getPaperPromise.then(function (paperRes) {
                resolve(paperRes.json());
            });
        });
        return result;
    };
    ProductsService.prototype.getPaperPage = function (paperId, pageNumber) {
        var headers = new http_1.Headers();
        this.auth.authorizeHeaders(headers);
        var opts = { headers: headers };
        var requestData = { paperId: paperId, pageNumber: pageNumber };
        var promise = this.http.post('http://localhost:8080/api/papers/page', requestData, opts).toPromise();
        var result = new Promise(function (resolve, reject) {
            promise.then(function (res) {
                resolve(res.text().replace(/"/g, ''));
            });
        });
        return result;
    };
    ProductsService.prototype.objectToQueryString = function (obj) {
        var parts = [];
        for (var i in obj) {
            if (obj.hasOwnProperty(i)) {
                parts.push(encodeURIComponent(i) + '=' + encodeURIComponent(obj[i]));
            }
        }
        return parts.join('&');
    };
    return ProductsService;
}());
// Observable string sources
ProductsService.searchEvent = new core_1.EventEmitter();
ProductsService = __decorate([
    core_1.Injectable(),
    __metadata("design:paramtypes", [router_1.Router,
        http_1.Http,
        auth_service_1.AuthService])
], ProductsService);
exports.ProductsService = ProductsService;
//# sourceMappingURL=products.service.js.map